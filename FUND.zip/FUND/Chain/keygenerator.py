from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed
from cryptography.hazmat.primitives.asymmetric.ecdsa import (
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
    EcdsaSignature,
)
import binascii


def sign_transaction(self):
    private_key = self.sender._private_key
    message = str(self.to_dict()).encode('utf-8')
    sk = ec.derive_private_key(
        int.from_bytes(private_key, byteorder='big'), ec.SECP256K1())
    signature = sk.sign(
        message, ec.ECDSA(hashes.SHA256()), Prehashed(hashes.SHA256()))
    r, s = signature.r.to_bytes(32, 'big'), signature.s.to_bytes(32, 'big')
    return binascii.hexlify(r + s).decode('ascii')
